package modele;

public class Horizon {
	
	private int posY;
	
	public Horizon(int posY) {
		this.posY = posY;
	}
	
	public int getY() {
		return this.posY;
	}

}
