package modele;

public class Utils {

	public static int valeurAbsolue(int v) {
		return v < 0 ? -v : v;
	}

}
