package modele;

public class Terrain {
	public final static int LARGEUR_TERRAIN = 1000;
	public final static int HAUTEUR_TERRAIN = 600;
	
	public Terrain() {
		
	}

}
